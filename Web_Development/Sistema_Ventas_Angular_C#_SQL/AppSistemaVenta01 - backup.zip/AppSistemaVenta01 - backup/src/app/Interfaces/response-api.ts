export interface ResponseApi {
    status:boolean,
    msg:string,
    value:any
}
