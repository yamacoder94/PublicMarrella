export interface Menu {

    idMenu:number,
    nombre:string,
    icono:string,
    url:string
}
