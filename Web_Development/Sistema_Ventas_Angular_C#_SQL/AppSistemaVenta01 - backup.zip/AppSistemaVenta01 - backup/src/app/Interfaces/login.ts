export interface Login {

    correo:string
    clave:	string
}
