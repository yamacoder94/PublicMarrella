export interface Producto {
    idProducto:number,
    nombreCompleto:string,
    idCategoria:number,
    descripcionCategoria:string,
    stock:number,
    precio:string,
    esActivo:number

}
