export interface Sesion {
    idUsuario:number,
    nombreCompleto:string,
    correo:string,
    rolDescripcion:string
}
