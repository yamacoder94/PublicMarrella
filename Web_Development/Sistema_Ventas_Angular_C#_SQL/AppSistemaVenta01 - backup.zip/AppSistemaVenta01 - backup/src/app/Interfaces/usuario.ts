export interface Usuario {
    idUsuario:number,
      nombreCompleto: string,
      correo: string,
      idRol: number,
      rolDescripcion: string,
      clave: string,
      esActivo: number
}
