export interface Rol {
    idRol:number,
    nombre:string
}
