export interface Reporte {
    numeroDocumento:string,
    tipoPago:string,
    fechaRegistro:string,
    totalVenta:string,
    producto:string,
    cantidad:number,
    precio:string,
    total:string
    idReporte:number,
}
