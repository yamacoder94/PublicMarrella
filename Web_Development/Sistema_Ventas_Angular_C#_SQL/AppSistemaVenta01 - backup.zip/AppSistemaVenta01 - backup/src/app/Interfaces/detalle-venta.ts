export interface DetalleVenta {

    idProducto:number,
    descripcionProducto:string,
    cantidad:number,
    precioTexto:String,
    totalTexto:string,
}
