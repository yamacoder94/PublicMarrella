export interface Categoria {
    idCategoria:number,
    nombre:string
}
