export const environment = {

    endpoint:"http://localhost:5166/api/"
};
