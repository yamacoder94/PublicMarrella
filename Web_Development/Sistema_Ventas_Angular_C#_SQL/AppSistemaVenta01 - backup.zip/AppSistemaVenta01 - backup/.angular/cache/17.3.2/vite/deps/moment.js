import {
  require_moment
} from "./chunk-62Y4XKTS.js";
import "./chunk-PZQZAEDH.js";
export default require_moment();
//# sourceMappingURL=moment.js.map
