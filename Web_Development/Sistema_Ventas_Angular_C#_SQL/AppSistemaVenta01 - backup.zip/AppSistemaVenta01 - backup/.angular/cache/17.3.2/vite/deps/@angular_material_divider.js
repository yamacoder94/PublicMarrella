import {
  MatDivider,
  MatDividerModule
} from "./chunk-OG224YTP.js";
import "./chunk-BJJZ6YT5.js";
import "./chunk-23ZHASDO.js";
import "./chunk-YOZZB2KP.js";
import "./chunk-KTHNHRW5.js";
import "./chunk-PZQZAEDH.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
