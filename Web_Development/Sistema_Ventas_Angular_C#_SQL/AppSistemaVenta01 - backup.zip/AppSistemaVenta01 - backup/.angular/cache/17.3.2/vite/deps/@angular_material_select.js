import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
} from "./chunk-PSMIMOOB.js";
import "./chunk-XYYXFD7I.js";
import "./chunk-OVNFRTBV.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-KH5XY7IW.js";
import "./chunk-XU7Z7KJY.js";
import "./chunk-5MMJIOKG.js";
import "./chunk-BZPD3QP4.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-BJJZ6YT5.js";
import "./chunk-23ZHASDO.js";
import "./chunk-YOZZB2KP.js";
import "./chunk-KTHNHRW5.js";
import "./chunk-PZQZAEDH.js";
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
