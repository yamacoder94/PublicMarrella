import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-WUISFML3.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-KH5XY7IW.js";
import "./chunk-XU7Z7KJY.js";
import "./chunk-BZPD3QP4.js";
import "./chunk-BJJZ6YT5.js";
import "./chunk-23ZHASDO.js";
import "./chunk-YOZZB2KP.js";
import "./chunk-KTHNHRW5.js";
import "./chunk-PZQZAEDH.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
