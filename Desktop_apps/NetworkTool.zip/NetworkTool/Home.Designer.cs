﻿
namespace NetworkTool
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.progMemory = new System.Windows.Forms.ProgressBar();
            this.lblram = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblbitlocker = new System.Windows.Forms.Label();
            this.hScrollBar1 = new System.Windows.Forms.HScrollBar();
            this.lblip = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblos = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lbllogonuser = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblmacaddress = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblhostname = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblversion = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(471, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(221, 66);
            this.label2.TabIndex = 1;
            this.label2.Text = "PC Info";
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(8, 623);
            this.splitter1.TabIndex = 17;
            this.splitter1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Control;
            this.panel3.Controls.Add(this.panel1);
            this.panel3.Controls.Add(this.progMemory);
            this.panel3.Controls.Add(this.lblram);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.lblbitlocker);
            this.panel3.Controls.Add(this.hScrollBar1);
            this.panel3.Controls.Add(this.lblip);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.lblos);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.lbllogonuser);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.lblmacaddress);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.lblhostname);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Location = new System.Drawing.Point(14, 14);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(896, 569);
            this.panel3.TabIndex = 25;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.BackgroundImage = global::NetworkTool.Properties.Resources._lock;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel1.Location = new System.Drawing.Point(317, 313);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(63, 53);
            this.panel1.TabIndex = 24;
            // 
            // progMemory
            // 
            this.progMemory.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.progMemory.Location = new System.Drawing.Point(326, 416);
            this.progMemory.Name = "progMemory";
            this.progMemory.Size = new System.Drawing.Size(262, 18);
            this.progMemory.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.progMemory.TabIndex = 23;
            // 
            // lblram
            // 
            this.lblram.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblram.AutoSize = true;
            this.lblram.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblram.Location = new System.Drawing.Point(386, 379);
            this.lblram.Name = "lblram";
            this.lblram.Size = new System.Drawing.Size(38, 25);
            this.lblram.TabIndex = 21;
            this.lblram.Text = "XX";
            this.lblram.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(331, 379);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 25);
            this.label5.TabIndex = 20;
            this.label5.Text = "C:\\";
            // 
            // lblbitlocker
            // 
            this.lblbitlocker.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblbitlocker.AutoSize = true;
            this.lblbitlocker.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblbitlocker.Location = new System.Drawing.Point(386, 327);
            this.lblbitlocker.Name = "lblbitlocker";
            this.lblbitlocker.Size = new System.Drawing.Size(38, 25);
            this.lblbitlocker.TabIndex = 19;
            this.lblbitlocker.Text = "XX";
            this.lblbitlocker.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // hScrollBar1
            // 
            this.hScrollBar1.Location = new System.Drawing.Point(588, 315);
            this.hScrollBar1.Name = "hScrollBar1";
            this.hScrollBar1.Size = new System.Drawing.Size(8, 8);
            this.hScrollBar1.TabIndex = 15;
            // 
            // lblip
            // 
            this.lblip.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblip.AutoSize = true;
            this.lblip.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblip.Location = new System.Drawing.Point(386, 276);
            this.lblip.Name = "lblip";
            this.lblip.Size = new System.Drawing.Size(218, 25);
            this.lblip.TabIndex = 14;
            this.lblip.Text = "VPN Disconnected ";
            this.lblip.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(326, 276);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 25);
            this.label1.TabIndex = 13;
            this.label1.Text = "IP :";
            // 
            // lblos
            // 
            this.lblos.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblos.AutoSize = true;
            this.lblos.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblos.Location = new System.Drawing.Point(386, 238);
            this.lblos.Name = "lblos";
            this.lblos.Size = new System.Drawing.Size(128, 25);
            this.lblos.TabIndex = 11;
            this.lblos.Text = "morana.11";
            this.lblos.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(326, 238);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 25);
            this.label12.TabIndex = 10;
            this.label12.Text = "OS :";
            // 
            // lbllogonuser
            // 
            this.lbllogonuser.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbllogonuser.AutoSize = true;
            this.lbllogonuser.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbllogonuser.Location = new System.Drawing.Point(471, 202);
            this.lbllogonuser.Name = "lbllogonuser";
            this.lbllogonuser.Size = new System.Drawing.Size(128, 25);
            this.lbllogonuser.TabIndex = 9;
            this.lbllogonuser.Text = "morana.11";
            this.lbllogonuser.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(326, 202);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(139, 25);
            this.label10.TabIndex = 8;
            this.label10.Text = "Logon user :";
            // 
            // lblmacaddress
            // 
            this.lblmacaddress.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblmacaddress.AutoSize = true;
            this.lblmacaddress.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblmacaddress.Location = new System.Drawing.Point(498, 168);
            this.lblmacaddress.Name = "lblmacaddress";
            this.lblmacaddress.Size = new System.Drawing.Size(218, 25);
            this.lblmacaddress.TabIndex = 7;
            this.lblmacaddress.Text = "CRSJODMJ0310QA";
            this.lblmacaddress.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(326, 168);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(166, 25);
            this.label8.TabIndex = 6;
            this.label8.Text = "Mac address :";
            // 
            // lblhostname
            // 
            this.lblhostname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblhostname.AutoSize = true;
            this.lblhostname.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblhostname.Location = new System.Drawing.Point(466, 133);
            this.lblhostname.Name = "lblhostname";
            this.lblhostname.Size = new System.Drawing.Size(218, 25);
            this.lblhostname.TabIndex = 5;
            this.lblhostname.Text = "CRSJODMJ0310QA";
            this.lblhostname.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(326, 133);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(134, 25);
            this.label6.TabIndex = 4;
            this.label6.Text = "Hostname :";
            this.label6.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.BackgroundImage = global::NetworkTool.Properties.Resources.traceRoute1;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(46, 118);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(226, 210);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // lblversion
            // 
            this.lblversion.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblversion.AutoSize = true;
            this.lblversion.BackColor = System.Drawing.SystemColors.Control;
            this.lblversion.Location = new System.Drawing.Point(838, 538);
            this.lblversion.Name = "lblversion";
            this.lblversion.Size = new System.Drawing.Size(36, 25);
            this.lblversion.TabIndex = 22;
            this.lblversion.Text = "1.0";
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.lblversion);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(144, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(926, 599);
            this.panel2.TabIndex = 25;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1186, 623);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Home";
            this.Text = "General";
            this.Load += new System.EventHandler(this.Home_Load);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ProgressBar progMemory;
        private System.Windows.Forms.Label lblram;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblbitlocker;
        private System.Windows.Forms.HScrollBar hScrollBar1;
        private System.Windows.Forms.Label lblip;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblos;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lbllogonuser;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblmacaddress;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblhostname;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblversion;
        private System.Windows.Forms.Panel panel2;
    }
}